set.seed(123456)
rm(list = ls())
#set directory to source folder
library(readr)
data <- read_csv("data.csv")

library(CBPS)
library(systemfit)

##balancing 
m4.s1 <- npCBPS(rf_0622~
                  Turnout15  +
                  UKIP14_pct+
                  femPerc+
                  percDE +  
                  logPop +
                  percDegree + 
                  medianAge +
                  England+postal_pct, 
                method='exact',
                data=data)

#### class interaction ####



####Estimation###

w5<- sqrt(m4.s1$weights)
X<- model.matrix(~rf_0622+
                   Turnout15  +
                   UKIP14_pct+
                   femPerc+
                   logPop +
                   percDegree + 
                   medianAge+
                   England + 
                   percDE*rf_0622, data = data)

X<-diag(w5)%*%X

Leave5 <- diag(w5)%*%log(data$leave_pct/data$abstain_pct)
Remain5 <-diag(w5)%*%log(data$remain_pct/data$abstain_pct)

m5eq1<- Leave5 ~ X-1
m5eq2<- Remain5 ~ X-1

m5 <- systemfit(list(m5eq1,m5eq2),method = 'SUR')

summary(m5)



# simulated coefficients
coefSimLeave <- mvrnorm(n=1000, m5[1]$eq[[1]]$coefficients, m5[1]$eq[[1]]$coefCov)
coefSimRemain  <- mvrnorm(n=1000, m5[1]$eq[[2]]$coefficients, m5[1]$eq[[2]]$coefCov)

## Rain Measures (high and low for first differences)
rainHigh      <-  25
rainLow       <-  0



####MARGINAL EFFECTS##


plotmat<-matrix(nrow=40, ncol=10)


for (j in 1:40){
  
  i<-seq(0,50, length.out=40)[j]
  

  ## Vector of Xs
  highRainVec <- c(1,rainHigh, mean(data$Turnout15), mean(data$UKIP14_pct),
                   mean(data$femPerc), mean(data$logPop), 
                   mean(data$percDegree), mean(data$medianAge),
                   mean(data$England), i, i*rainHigh)
  
  
  lowRainVec <-  c(1,rainLow,  mean(data$Turnout15), mean(data$UKIP14_pct),
                   mean(data$femPerc), mean(data$logPop), 
                   mean(data$percDegree), mean(data$medianAge),
                   mean(data$England), i, i*rainLow)
  
  
  ## Predicted ln(RemainShare/AbstainShare) (for both high and low rain)
  pred.remain.low  <- coefSimRemain %*% lowRainVec
  pred.remain.high <- coefSimRemain %*% highRainVec
  
  ## Predicted ln(LeaveShare/AbstainShare) (for both high and low rain)
  pred.leave.low  <- coefSimLeave %*% lowRainVec
  pred.leave.high <- coefSimLeave %*% highRainVec
  
  ## Predicted Share Values for Remain : Rhat
  lowRemainShare  <- exp(pred.remain.low)  / (1 + exp(pred.remain.low)  + exp(pred.leave.low)  )
  highRemainShare <- exp(pred.remain.high) / (1 + exp(pred.remain.high) + exp(pred.leave.high) )
  
  ## Predicted Share Values for Leave : Lhat
  lowLeaveShare  <- exp(pred.leave.low)  / (1 + exp(pred.leave.low)   +  exp(pred.remain.low)   )
  highLeaveShare <- exp(pred.leave.high) / (1 + exp(pred.leave.high)  +  exp(pred.remain.high)  )
  
  ## Predicted Share Values for Abstain : 100 - Rhat - Lhat
  lowAbstainShare  <- 1  / (1 + exp(pred.leave.low)   +  exp(pred.remain.low)   )
  highAbstainShare <- 1 / (1 + exp(pred.leave.high)  +  exp(pred.remain.high)  )
  
  
  
  ## First Differences
  fd_abstain <- highAbstainShare - lowAbstainShare
  fd_remain  <- highRemainShare  - lowRemainShare
  fd_leave   <- highLeaveShare   - lowLeaveShare
  
  total_remain_advantage <- fd_remain - fd_leave
  
  modelnumber<-j
  
  plotmat[modelnumber,1]<-mean(fd_abstain)
  plotmat[modelnumber,2]<-quantile(fd_abstain, 0.975)
  plotmat[modelnumber,3]<-quantile(fd_abstain, 0.025)
  
  plotmat[modelnumber,4]<-mean(fd_remain)
  plotmat[modelnumber,5]<-quantile(fd_remain, 0.975)
  plotmat[modelnumber,6]<-quantile(fd_remain, 0.025)
  
  plotmat[modelnumber,7]<-mean(fd_leave)
  plotmat[modelnumber,8]<-quantile(fd_leave, 0.975)
  plotmat[modelnumber,9]<-quantile(fd_leave, 0.025)
  
  plotmat[modelnumber,10]<- i

}

plotmat[, 1:9]<- plotmat[,1:9]*100

# create transparent colour
t_col <- function(color, percent = 50, name = NULL) {

  rgb.val <- col2rgb(color)
  ## Make new color using input color as base and alpha set by transparency
  t.col <- rgb(rgb.val[1], rgb.val[2], rgb.val[3],
               max = 255,
               alpha = (100-percent)*255/100,
               names = name)
  ## Save the color
  invisible(t.col)
  
}
g1<-t_col('black', 80)

#PLOT
par(mfrow=c(3,3),mai=c(.4,0.4,0.1,0.1))


#abstain
plot(plotmat[,10]-1, plotmat[,1], type = 'n', 
     ylim= c(-20,20), xlim= c(0,50),
     axes=F, pch=4,
     xlab= '',
     ylab = '')
title(xlab='Low Social Class (%)',
      line=1.7)
title(ylab=expression(italic(paste(Delta,hat(A), sep=''))),
     line=1.7)

axis(1, at=seq(0, 50,10), padj=-0.5)
axis(2, at=seq(-20,20,5), padj=0.5)

polygon(c(plotmat[,10],rev(plotmat[,10])),
        c(plotmat[,2],rev(plotmat[,3])),border = NA,col=g1)
lines(plotmat[,10],plotmat[,1],lwd=2)
box()
abline(h=0,lty=3, lwd=0.5)


#leave
plot(plotmat[,10], plotmat[,1], type = 'n', 
     ylim= c(-20,20), xlim= c(0,50),
     axes=F, pch=4,
     xlab= '', 
     ylab = '')

title(xlab='Low Social Class (%)',
      line=1.7)

axis(1, at=seq(0, 50,10), padj=-0.5)
axis(2, at=seq(-20,20,5), padj=0.5)



polygon(c(plotmat[,10],rev(plotmat[,10])),
        c(plotmat[,8],rev(plotmat[,9])),border=NA,col=g1)


lines(plotmat[,10],plotmat[,7],lty=3,lwd=2)
title(ylab=expression(italic(paste(Delta,hat(L), sep=''))),
      line=1.7)
abline(h=0,lty=3, lwd=0.5)
box()

#remain
plot(plotmat[,10], plotmat[,1], type = 'n', 
     ylim= c(-20,20), xlim= c(0,50),
     axes=F, pch=4,
     xlab= '', 
     ylab = '')

title(xlab='Low Social Class (%)',
      line=1.7)
title(ylab=expression(italic(paste(Delta,hat(R), sep=''))),
      line=1.7)
axis(1, at=seq(0, 50,10), padj=-0.5)
axis(2, at=seq(-20,20,5), padj=0.5)

polygon(c(plotmat[,10],rev(plotmat[,10])),
        c(plotmat[,5],rev(plotmat[,6])),border=NA,col=g1)
lines(plotmat[,10],plotmat[,4], lty=2, lwd=2)
abline(h=0,lty=3, lwd=0.5)
box()

#### age interaction ####


w5<- sqrt(m4.s1$weights)
X<- model.matrix(~rf_0622+
                   Turnout15  +
                   UKIP14_pct+
                   femPerc+
                   percDE +  
                   logPop +
                   percDegree + 
                   England + 
                   medianAge*rf_0622, data = data)

X<-diag(w5)%*%X

Leave5 <- diag(w5)%*%log(data$leave_pct/data$abstain_pct)
Remain5 <-diag(w5)%*%log(data$remain_pct/data$abstain_pct)

m5eq1<- Leave5 ~ X-1
m5eq2<- Remain5 ~ X-1

m5 <- systemfit(list(m5eq1,m5eq2),method = 'SUR')

summary(m5)



# simulated coefficients
coefSimLeave <- mvrnorm(n=1000, m5[1]$eq[[1]]$coefficients, m5[1]$eq[[1]]$coefCov)
coefSimRemain  <- mvrnorm(n=1000, m5[1]$eq[[2]]$coefficients, m5[1]$eq[[2]]$coefCov)

## Rain Measures (high and low for first differences)
rainHigh      <-  25
rainLow       <-  0



####MARGINAL EFFECTS###


plotmat<-matrix(nrow=40, ncol=10)


for (j in 1:40){
  
  i<-seq(30,60, length.out=40)[j]
  
  
  ## Vector of Xs
  highRainVec <- c(1,rainHigh, mean(data$Turnout15), mean(data$UKIP14_pct),
                   mean(data$femPerc), mean(data$percDE), mean(data$logPop), 
                   mean(data$percDegree), 
                   mean(data$England), i, i*rainHigh)
  
  
  lowRainVec <-  c(1,rainLow,  mean(data$Turnout15), mean(data$UKIP14_pct),
                   mean(data$femPerc), mean(data$percDE), mean(data$logPop), 
                   mean(data$percDegree),
                   mean(data$England), i, i*rainLow)
  
  
  ## Predicted ln(RemainShare/AbstainShare) (for both high and low rain)
  pred.remain.low  <- coefSimRemain %*% lowRainVec
  pred.remain.high <- coefSimRemain %*% highRainVec
  
  ## Predicted ln(LeaveShare/AbstainShare) (for both high and low rain)
  pred.leave.low  <- coefSimLeave %*% lowRainVec
  pred.leave.high <- coefSimLeave %*% highRainVec
  
  ## Predicted Share Values for Remain : Rhat
  lowRemainShare  <- exp(pred.remain.low)  / (1 + exp(pred.remain.low)  + exp(pred.leave.low)  )
  highRemainShare <- exp(pred.remain.high) / (1 + exp(pred.remain.high) + exp(pred.leave.high) )
  
  ## Predicted Share Values for Leave : Lhat
  lowLeaveShare  <- exp(pred.leave.low)  / (1 + exp(pred.leave.low)   +  exp(pred.remain.low)   )
  highLeaveShare <- exp(pred.leave.high) / (1 + exp(pred.leave.high)  +  exp(pred.remain.high)  )
  
  ## Predicted Share Values for Abstain : 100 - Rhat - Lhat
  lowAbstainShare  <- 1  / (1 + exp(pred.leave.low)   +  exp(pred.remain.low)   )
  highAbstainShare <- 1 / (1 + exp(pred.leave.high)  +  exp(pred.remain.high)  )
  
  
  
  ## First Differences
  fd_abstain <- highAbstainShare - lowAbstainShare
  fd_remain  <- highRemainShare  - lowRemainShare
  fd_leave   <- highLeaveShare   - lowLeaveShare
  
  total_remain_advantage <- fd_remain - fd_leave
  
  modelnumber<-j
  
  plotmat[modelnumber,1]<-mean(fd_abstain)
  plotmat[modelnumber,2]<-quantile(fd_abstain, 0.975)
  plotmat[modelnumber,3]<-quantile(fd_abstain, 0.025)
  
  plotmat[modelnumber,4]<-mean(fd_remain)
  plotmat[modelnumber,5]<-quantile(fd_remain, 0.975)
  plotmat[modelnumber,6]<-quantile(fd_remain, 0.025)
  
  plotmat[modelnumber,7]<-mean(fd_leave)
  plotmat[modelnumber,8]<-quantile(fd_leave, 0.975)
  plotmat[modelnumber,9]<-quantile(fd_leave, 0.025)
  
  plotmat[modelnumber,10]<- i
  
}

plotmat[, 1:9]<- plotmat[,1:9]*100


#abstain
plot(plotmat[,10]-1, plotmat[,1], type = 'n', 
     ylim= c(-20,20), xlim= c(30,60),
     axes=F, pch=4,
     xlab= '',
     ylab = '')
title(xlab='Median Age (%)',
      line=1.7)
title(ylab=expression(italic(paste(Delta,hat(A), sep=''))),
      line=1.7)

axis(1, at=seq(30, 60,10), padj=-0.5)
axis(2, at=seq(-20,20,5), padj=0.5)

polygon(c(plotmat[,10],rev(plotmat[,10])),
        c(plotmat[,2],rev(plotmat[,3])),border = NA,col=g1)
lines(plotmat[,10],plotmat[,1],lwd=2)
box()
abline(h=0,lty=3, lwd=0.5)


#leave
plot(plotmat[,10], plotmat[,1], type = 'n', 
     ylim= c(-20,20), xlim= c(30,60),
     axes=F, pch=4,
     xlab= '', 
     ylab = '')

title(xlab='Median Age (%)',
      line=1.7)

axis(1, at=seq(30, 60,10), padj=-0.5)
axis(2, at=seq(-20,20,5), padj=0.5)



polygon(c(plotmat[,10],rev(plotmat[,10])),
        c(plotmat[,8],rev(plotmat[,9])),border=NA,col=g1)


lines(plotmat[,10],plotmat[,7],lty=3,lwd=2)
title(ylab=expression(italic(paste(Delta,hat(L), sep=''))),
      line=1.7)

box()
abline(h=0,lty=3, lwd=0.5)

#remain
plot(plotmat[,10], plotmat[,1], type = 'n', 
     ylim= c(-20,20), xlim= c(30,60),
     axes=F, pch=4,
     xlab= '', 
     ylab = '')

title(xlab='Median Age (%)',
      line=1.7)
title(ylab=expression(italic(paste(Delta,hat(R), sep=''))),
      line=1.7)
axis(1, at=seq(30, 60,10), padj=-0.5)
axis(2, at=seq(-20,20,5), padj=0.5)

polygon(c(plotmat[,10],rev(plotmat[,10])),
        c(plotmat[,5],rev(plotmat[,6])),border=NA,col=g1)
lines(plotmat[,10],plotmat[,4], lty=2, lwd=2)

box()
abline(h=0,lty=3, lwd=0.5)



#### habit interaction ####

w5<- sqrt(m4.s1$weights)
X<- model.matrix(~rf_0622+
                   UKIP14_pct+
                   femPerc+
                   percDE+
                   logPop +
                   percDegree + 
                   medianAge+
                   England + 
                   Turnout15*rf_0622, data = data)

X<-diag(w5)%*%X

Leave5 <- diag(w5)%*%log(data$leave_pct/data$abstain_pct)
Remain5 <-diag(w5)%*%log(data$remain_pct/data$abstain_pct)

m5eq1<- Leave5 ~ X-1
m5eq2<- Remain5 ~ X-1

m5 <- systemfit(list(m5eq1,m5eq2),method = 'SUR')

summary(m5)



# simulated coefficients
coefSimLeave <- mvrnorm(n=1000, m5[1]$eq[[1]]$coefficients, m5[1]$eq[[1]]$coefCov)
coefSimRemain  <- mvrnorm(n=1000, m5[1]$eq[[2]]$coefficients, m5[1]$eq[[2]]$coefCov)

## Rain Measures (high and low for first differences)
rainHigh      <-  25
rainLow       <-  0



####MARGINAL EFFECTS###


plotmat<-matrix(nrow=40, ncol=10)


for (j in 1:40){
  
  i<-seq(40,90, length.out=40)[j]
  
  
  ## Vector of Xs
  highRainVec <- c(1,rainHigh, mean(data$UKIP14_pct),
                   mean(data$femPerc), mean(data$percDE), mean(data$logPop), 
                   mean(data$percDegree), mean(data$medianAge),
                   mean(data$England), i, i*rainHigh)
  
  
  lowRainVec <-  c(1,rainLow, mean(data$UKIP14_pct),
                   mean(data$femPerc), mean(data$percDE), mean(data$logPop), 
                   mean(data$percDegree), mean(data$medianAge),
                   mean(data$England), i, i*rainLow)
  
  
  ## Predicted ln(RemainShare/AbstainShare) (for both high and low rain)
  pred.remain.low  <- coefSimRemain %*% lowRainVec
  pred.remain.high <- coefSimRemain %*% highRainVec
  
  ## Predicted ln(LeaveShare/AbstainShare) (for both high and low rain)
  pred.leave.low  <- coefSimLeave %*% lowRainVec
  pred.leave.high <- coefSimLeave %*% highRainVec
  
  ## Predicted Share Values for Remain : Rhat
  lowRemainShare  <- exp(pred.remain.low)  / (1 + exp(pred.remain.low)  + exp(pred.leave.low)  )
  highRemainShare <- exp(pred.remain.high) / (1 + exp(pred.remain.high) + exp(pred.leave.high) )
  
  ## Predicted Share Values for Leave : Lhat
  lowLeaveShare  <- exp(pred.leave.low)  / (1 + exp(pred.leave.low)   +  exp(pred.remain.low)   )
  highLeaveShare <- exp(pred.leave.high) / (1 + exp(pred.leave.high)  +  exp(pred.remain.high)  )
  
  ## Predicted Share Values for Abstain : 100 - Rhat - Lhat
  lowAbstainShare  <- 1  / (1 + exp(pred.leave.low)   +  exp(pred.remain.low)   )
  highAbstainShare <- 1 / (1 + exp(pred.leave.high)  +  exp(pred.remain.high)  )
  
  
  
  ## First Differences
  fd_abstain <- highAbstainShare - lowAbstainShare
  fd_remain  <- highRemainShare  - lowRemainShare
  fd_leave   <- highLeaveShare   - lowLeaveShare
  
  total_remain_advantage <- fd_remain - fd_leave
  
  modelnumber<-j
  
  plotmat[modelnumber,1]<-mean(fd_abstain)
  plotmat[modelnumber,2]<-quantile(fd_abstain, 0.975)
  plotmat[modelnumber,3]<-quantile(fd_abstain, 0.025)
  
  plotmat[modelnumber,4]<-mean(fd_remain)
  plotmat[modelnumber,5]<-quantile(fd_remain, 0.975)
  plotmat[modelnumber,6]<-quantile(fd_remain, 0.025)
  
  plotmat[modelnumber,7]<-mean(fd_leave)
  plotmat[modelnumber,8]<-quantile(fd_leave, 0.975)
  plotmat[modelnumber,9]<-quantile(fd_leave, 0.025)
  
  plotmat[modelnumber,10]<- i
  
}

plotmat[, 1:9]<- plotmat[,1:9]*100


#abstain
plot(plotmat[,10]-1, plotmat[,1], type = 'n', 
     ylim= c(-20,20), xlim= c(40,90),
     axes=F, pch=4,
     xlab= '',
     ylab = '')
title(xlab='Turnout 2015 (%)',
      line=1.7)
title(ylab=expression(italic(paste(Delta,hat(A), sep=''))),
      line=1.7)

axis(1, at=seq(40, 90,10), padj=-0.5)
axis(2, at=seq(-20,20,5), padj=0.5)

polygon(c(plotmat[,10],rev(plotmat[,10])),
        c(plotmat[,2],rev(plotmat[,3])),border = NA,col=g1)
lines(plotmat[,10],plotmat[,1],lwd=2)
box()
abline(h=0,lty=3, lwd=0.5)


#leave
plot(plotmat[,10], plotmat[,1], type = 'n', 
     ylim= c(-20,20), xlim= c(40,90),
     axes=F, pch=4,
     xlab= '', 
     ylab = '')

title(xlab='Turnout 2015 (%)',
      line=1.7)

axis(1, at=seq(40, 90,10), padj=-0.5)
axis(2, at=seq(-20,20,5), padj=0.5)



polygon(c(plotmat[,10],rev(plotmat[,10])),
        c(plotmat[,8],rev(plotmat[,9])),border=NA,col=g1)


lines(plotmat[,10],plotmat[,7],lty=3,lwd=2)
title(ylab=expression(italic(paste(Delta,hat(L), sep=''))),
      line=1.7)

box()
abline(h=0,lty=3, lwd=0.5)

#remain
plot(plotmat[,10], plotmat[,1], type = 'n', 
     ylim= c(-20,20), xlim= c(40,90),
     axes=F, pch=4,
     xlab= '', 
     ylab = '')

title(xlab='Turnout 2015 (%)',
      line=1.7)
title(ylab=expression(italic(paste(Delta,hat(R), sep=''))),
      line=1.7)
axis(1, at=seq(40, 90,10), padj=-0.5)
axis(2, at=seq(-20,20,5), padj=0.5)

polygon(c(plotmat[,10],rev(plotmat[,10])),
        c(plotmat[,5],rev(plotmat[,6])),border=NA,col=g1)
lines(plotmat[,10],plotmat[,4], lty=2, lwd=2)

box()

abline(h=0,lty=3, lwd=0.5)




#### output ####
#dev.copy(pdf,"interaction9.pdf", width=6, height=6)
#dev.off()

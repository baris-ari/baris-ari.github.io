set.seed(123456)
rm(list = ls())
#set directory to source folder
library(readr)
data <- read_csv("data.csv")
library(CBPS)
library(systemfit)


##### MINUTES MODEL #####


m6.s1 <- npCBPS(minutes_0622~
                  Turnout15  +
                  UKIP14_pct+
                  femPerc+
                  percDE +  
                  logPop +
                  percDegree + 
                  medianAge +
                  England+postal_pct, 
                method='exact',
                data=data)

w6<- sqrt(m6.s1$weights)
X<- model.matrix(~minutes_0622+
                   Turnout15  +
                   UKIP14_pct+
                   femPerc+
                   percDE +  
                   logPop +
                   percDegree + 
                   medianAge + 
                   England, data = data)

X<-diag(w6)%*%X

Leave6 <- diag(w6)%*%log(data$leave_pct/data$abstain_pct)
Remain6 <-diag(w6)%*%log(data$remain_pct/data$abstain_pct)

m6eq1<- Leave6 ~ X-1
m6eq2<- Remain6 ~ X-1

m6 <- systemfit(list(m6eq1,m6eq2),method = 'SUR')

summary(m6)
texreg(m6, digit=4)

# simulated coefficients
coefSimLeave <- mvrnorm(n=960, m6[1]$eq[[1]]$coefficients, m6[1]$eq[[1]]$coefCov)
coefSimRemain  <- mvrnorm(n=960, m6[1]$eq[[2]]$coefficients, m6[1]$eq[[2]]$coefCov)

## Rain Measures (high and low for first differences)

rainHigh      <-  960
rainLow       <-  0

#choose data frame


## Vector of Xs
highRainVec <- c(1,rainHigh, mean(data$Turnout15), mean(data$UKIP14_pct),
                 mean(data$femPerc), mean(data$percDE), mean(data$logPop), 
                 mean(data$percDegree), 
                 mean(data$medianAge), 
                 mean(data$England))


lowRainVec <- c(1,rainLow,  mean(data$Turnout15), mean(data$UKIP14_pct),
                mean(data$femPerc), mean(data$percDE), mean(data$logPop), 
                mean(data$percDegree), 
                mean(data$medianAge), 
                mean(data$England))


## Predicted ln(RemainShare/AbstainShare) (for both high and low rain)
pred.remain.low  <- coefSimRemain %*% lowRainVec
pred.remain.high <- coefSimRemain %*% highRainVec

## Predicted ln(LeaveShare/AbstainShare) (for both high and low rain)
pred.leave.low  <- coefSimLeave %*% lowRainVec
pred.leave.high <- coefSimLeave %*% highRainVec

## Predicted Share Values for Remain : Rhat
lowRemainShare  <- exp(pred.remain.low)  / (1 + exp(pred.remain.low)  + exp(pred.leave.low)  )
highRemainShare <- exp(pred.remain.high) / (1 + exp(pred.remain.high) + exp(pred.leave.high) )

## Predicted Share Values for Leave : Lhat
lowLeaveShare  <- exp(pred.leave.low)  / (1 + exp(pred.leave.low)   +  exp(pred.remain.low)   )
highLeaveShare <- exp(pred.leave.high) / (1 + exp(pred.leave.high)  +  exp(pred.remain.high)  )

## Predicted Share Values for Abstain : 100 - Rhat - Lhat
lowAbstainShare  <- 1  / (1 + exp(pred.leave.low)   +  exp(pred.remain.low)   )
highAbstainShare <- 1 / (1 + exp(pred.leave.high)  +  exp(pred.remain.high)  )

## First Differences
fd_abstain <- highAbstainShare - lowAbstainShare
fd_remain  <- highRemainShare  - lowRemainShare
fd_leave   <- highLeaveShare   - lowLeaveShare

total_remain_advantage <- fd_remain - fd_leave

#Remove plotmat later
plotmat<- matrix(nrow=5, ncol=9)

modelnumber<-1

plotmat[modelnumber,1]<-mean(fd_abstain)*100
plotmat[modelnumber,2]<-quantile(fd_abstain, 0.975)*100
plotmat[modelnumber,3]<-quantile(fd_abstain, 0.025)*100

plotmat[modelnumber,4]<-mean(fd_remain)*100
plotmat[modelnumber,5]<-quantile(fd_remain, 0.975)*100
plotmat[modelnumber,6]<-quantile(fd_remain, 0.025)*100

plotmat[modelnumber,7]<-mean(fd_leave)*100
plotmat[modelnumber,8]<-quantile(fd_leave, 0.975)*100
plotmat[modelnumber,9]<-quantile(fd_leave, 0.025)*100

#PLOT
par(mfrow=c(1,1), mai=c(0.8,1,0.5,0.5))
plot(x= 1 , y =1, type='n', ylim = c(-3,3), 
     xlim = c(-2,4), axes=F, xlab = '',
     ylab=expression(italic(paste(Delta,'Referendum Result (%)'))))
axis(2)
axis(1, at=c(1), line=1,tick = F,
     labels=c('06h-22h\nRain (16 hrs)\nw.weights'))
abline(h=0, lty=2)

#abstain plot
points(x = modelnumber-1, y=plotmat[modelnumber,1], pch=4)
segments(modelnumber-1,plotmat[modelnumber,2],modelnumber-1,plotmat[modelnumber,3], 
         lwd=2, col= 'black')

#remain plot
points(x = modelnumber, y=plotmat[modelnumber,4], pch=19, col= 'gray75')
segments(modelnumber,plotmat[modelnumber,5],modelnumber,plotmat[modelnumber,6], 
         lwd=2, col= 'gray75')

#leave plot

points(x = modelnumber+1, y=plotmat[modelnumber,7], pch=15, col= 'gray40')
segments(modelnumber+1,plotmat[modelnumber,8],modelnumber+1,plotmat[modelnumber,9], 
         lwd=2, col= 'gray40')



box()


#### output ####
#dev.copy(pdf,"appendixMods.pdf", width=4, height=3.5)
#dev.off()

set.seed(123456)
rm(list = ls())
#set directory to source folder
library(readr)
data <- read_csv("data.csv")

RLcount <- read_csv("remainLeaveCounts.csv")
data<-merge(data, RLcount, by='Area')

data$Remain<- log(data$remain_pct/data$abstain_pct)
data$Leave<- log(data$leave_pct/data$abstain_pct)




library(CBPS)
library(systemfit)




balance <- npCBPS(rf_0622~
                    Turnout15  +
                    UKIP14_pct+
                    femPerc+
                    percDE +  
                    logPop +
                    percDegree + 
                    medianAge +
                    England+postal_pct, 
                  method='exact',
                  data=data)




w<- sqrt(balance$weights)
X<- model.matrix(~rf_0622+
                   Turnout15  +
                   UKIP14_pct+
                   femPerc+
                   percDE +  
                   logPop +
                   percDegree + 
                   medianAge + 
                   England, data = data)

X<-diag(w)%*%X

Leave <- diag(w)%*%log(data$leave_pct/data$abstain_pct)
Remain <-diag(w)%*%log(data$remain_pct/data$abstain_pct)

m5l<- Leave ~ X-1
m5r<- Remain ~ X-1

m5<- systemfit(list(m5l,m5r),method = 'SUR')






#### plot 4 setup ####

plotmat <- matrix(nrow=5,ncol=9)





####  Actual Result ####

LEAVE <- sum(data$LeaveCount)/sum(data$Valid_Votes)*100
REMAIN <- sum(data$RemainCount)/sum(data$Valid_Votes)*100







####  MODEL  ####



# simulated coefficients
BetaRainL <- mvrnorm(n=10000, m5[1]$eq[[1]]$coefficients, m5[1]$eq[[1]]$coefCov)
BetaRainR  <- mvrnorm(n=10000, m5[1]$eq[[2]]$coefficients, m5[1]$eq[[2]]$coefCov)



remainM5<-matrix(nrow=10000, ncol=1)
leaveM5<-matrix(nrow=10000, ncol=1)
abstainM5<-matrix(nrow=10000, ncol=1)


for (i in 1:10000){
  sunnyL <- data$Leave  - BetaRainL[i,2]*data$rf_0622
  sunnyR <- data$Remain   - BetaRainR[i,2]*data$rf_0622
  
  l <- exp(sunnyL)/(1+exp(sunnyL)+exp(sunnyR))
  r <- exp(sunnyR)/(1+exp(sunnyL)+exp(sunnyR))
  

  leave<- l*data$Electorate
  remain<- r*data$Electorate

  
  r2 <- sum(remain)/sum(data$Electorate)
  l2 <- sum(leave)/sum(data$Electorate)

  remainM5[i]<-r2/(r2+l2)
  leaveM5[i]<-l2/(r2+l2)
}





plotmat<- matrix(nrow=5, ncol=9)

modelnumber<-2



plotmat[modelnumber,4]<-mean(remainM5)*100
plotmat[modelnumber,5]<-quantile(remainM5, 0.975)*100
plotmat[modelnumber,6]<-quantile(remainM5, 0.025)*100

plotmat[modelnumber,7]<-mean(leaveM5)*100
plotmat[modelnumber,8]<-quantile(leaveM5, 0.975)*100
plotmat[modelnumber,9]<-quantile(leaveM5, 0.025)*100
  




#plot
par(mai=c(0.5,.7,0.3,0.3),mfrow=c(1,1))

plot(x=NULL,y=NULL,main=NULL, 
     ylab = '', xlab = '',
     xlim=c(1.6,3.4), ylim= c(47,53), 
     axes=F, type = 'n')

title(ylab='Referendum Result (%)', line=1.7)
axis(1, at= c(1,2,3), labels = c('Abstain', 'Leave', 'Remain'),
    padj=-0.5)
axis(2, padj=0.5)
abline(h=50,lty=3)
box()



#leave
points(x = 2, y=plotmat[modelnumber,7],cex=1, pch=19, col= 'gray50')
segments(2,plotmat[modelnumber,8],2,plotmat[modelnumber,9], 
         lwd=2, col= 'gray50')
points(x = 1.9, y=LEAVE,cex=1, pch=19, col= 'black')

#remain

points(x = 3, y=plotmat[modelnumber,4],cex=1, pch=19, col= 'gray50')
segments(3,plotmat[modelnumber,5],3,plotmat[modelnumber,6], 
         lwd=2, col= 'gray50')
points(x = 2.9, y=REMAIN,cex=1, pch=19, col= 'black')


sum(data$Valid_Votes)*mean(leaveM5)-sum(data$Valid_Votes)*mean(remainM5)

#### output ####
#dev.copy(pdf,"sunny_day_plot.pdf", width=4, height=3.5)
#dev.off()












######################################################################
# Analysis UN involvement and civil war peace accord implementation
# written by: Wakako Maekawa
# Last modified: 2018/08/17
######################################################################

#--------------------------------------------------#
# Analysis (Main Table implemented in Stata xtpcse)
#--------------------------------------------------#
rm(list = ls())
library(foreign)
re1 = read.table("Results/PCSE results model1.txt", sep="")
re1$V2 = NULL
re1

re2 = read.table("Results/PCSE results model2.txt", sep="")
re2$V2 = NULL
re2

re3 = read.table("Results/PCSE results model3.txt", sep="")
re3$V2 = NULL
re3

# Custom code for Figure 1 ----------#
rm(list = ls())
dt = read.csv("data.csv")
head(dt)
# total number of troops variable
dt$total_y <- dt$milobs_y+dt$police_y+dt$troop_y
dt$total_y[dt$country=="India"] = 0 # make the UN missions in India as 0 --> because the are deployed was irrelevant
# power-sharing provision
dt$pow_prov = ifelse(dt$powtran_prov==1|dt$terpow_prov==1,1,0)
# subset dataset
sub = na.omit(dt[,c("score_nonUN","score_nonUN_lag","total_y","political_mission","bd_best","gdp_m1","pop_m1","elec_index_m1","country","year",
                    "sg_power_vdem_m1","conf_durat_year_m1","numberofreb_m1","pam_caseid","pow_prov","terrcont","leverage_m1")])
library(foreign)
re = read.table("Results/PCSE results model3.txt", sep="")
re$V2 = NULL
r.coef = re$V3
re.vcov = read.table("Results/PCSE variance-covariance-matrix.txt", sep="\t")
library(stringr)
matrix = matrix(NA,16,17)
for (i in 1:length(re.vcov$V1)){
  if(i==1){
    matrix[i,] = unlist(str_split(re.vcov$V1[i]," "))[unlist(str_split(re.vcov$V1[i]," "))!=""]
  }
  else{
    matrix[i,] = append(unlist(str_split(re.vcov$V1[i]," "))[unlist(str_split(re.vcov$V1[i]," "))!=""],rep(NA,(16-i)))
  }
}
matrix = matrix[-1,-c(1,2)]
matrix[upper.tri(matrix)] <- matrix[lower.tri(matrix)]
r.vcov = apply(matrix,2,as.numeric)

library(MASS)
set.seed(1234)
simb<- mvrnorm(1000,r.coef,r.vcov)
# check order
unlist(str_split(re.vcov$V1[1]," "))[unlist(str_split(re.vcov$V1[1]," "))!=""]
x_range_main <- seq(from = min(log(sub$total_y+1)), to = max(log(sub$total_y+1)))
set.x3 <- cbind(mean(sub$score_nonUN_lag),x_range_main,mean(sub$political_mission),mean(log(sub$bd_best+1)),
                mean(log(sub$gdp_m1)),mean(log(sub$pop_m1)),mean(sub$elec_index_m1),mean(sub$sg_power_vdem_m1),
                mean(log(sub$conf_durat_year_m1+1)),mean(sub$leverage_m1),mean(sub$numberofreb_m1),1,0,0,1)
x.beta3 <- set.x3 %*% t(simb)
quantile.values <- apply(X = x.beta3, MARGIN = 1, FUN = quantile, probs = c(.025,.5,.975))
plot.points <- cbind(x_range_main, t(quantile.values))
x.rng <- c(min(x_range_main), max(x_range_main)) 
y.rng <- c(66,75) 

par(mar=c(3,3,3,2),cex.lab=1.2,cex.axis=1.2,mgp=c(1.5,0.5,0), cex.main=1.5, cex=0.8,bg="white")
plot(x = x.rng, y = y.rng,xlab = "Log UN total personnel",
     ylab = "Implementation score (%)",main = "(a) Effects of UN total personnel on implementation score (%)", type = "n") 
lines(cbind(plot.points[,1],plot.points[,2]), lty = 2) 
lines(cbind(plot.points[,1],plot.points[,3]), lty = 1) 
lines(cbind(plot.points[,1],plot.points[,4]), lty = 2) 
rug(jitter(log(sub$total_y+1)), side=1)

# Custom code for Figure 2 ----------#
set.t0p1 <- cbind(mean(sub$score_nonUN_lag),mean(log(sub$total_y+1)),mean(sub$political_mission),
                  mean(log(sub$bd_best+1)),mean(log(sub$gdp_m1)),mean(log(sub$pop_m1)),
                  mean(sub$elec_index_m1),mean(sub$sg_power_vdem_m1),mean(log(sub$conf_durat_year_m1+1)),
                  mean(sub$leverage_m1),mean(sub$numberofreb_m1),1,0,0,1)
set.t1p0 <- cbind(mean(sub$score_nonUN_lag),mean(log(sub$total_y+1)),mean(sub$political_mission),
                  mean(log(sub$bd_best+1)),mean(log(sub$gdp_m1)),mean(log(sub$pop_m1)),
                  mean(sub$elec_index_m1),mean(sub$sg_power_vdem_m1),mean(log(sub$conf_durat_year_m1+1)),
                  mean(sub$leverage_m1),mean(sub$numberofreb_m1),0,1,0,1)
set.t1p1 <- cbind(mean(sub$score_nonUN_lag),mean(log(sub$total_y+1)),mean(sub$political_mission),
                  mean(log(sub$bd_best+1)),mean(log(sub$gdp_m1)),mean(log(sub$pop_m1)),
                  mean(sub$elec_index_m1),mean(sub$sg_power_vdem_m1),mean(log(sub$conf_durat_year_m1+1)),
                  mean(sub$leverage_m1),mean(sub$numberofreb_m1),0,0,1,1)
set.t0p0 <- cbind(mean(sub$score_nonUN_lag),mean(log(sub$total_y+1)),mean(sub$political_mission),
                  mean(log(sub$bd_best+1)),mean(log(sub$gdp_m1)),mean(log(sub$pop_m1)),
                  mean(sub$elec_index_m1),mean(sub$sg_power_vdem_m1),mean(log(sub$conf_durat_year_m1+1)),
                  mean(sub$leverage_m1),mean(sub$numberofreb_m1),0,0,0,1)

x.betat0p1 <- set.t0p1 %*% t(simb);x.betat1p0 <- set.t1p0 %*% t(simb);x.betat1p1 <- set.t1p1 %*% t(simb);x.betat0p0 <- set.t0p0 %*% t(simb)
quantile.values0p1 <- apply(X = x.betat0p1, MARGIN = 1, FUN = quantile, probs = c(.025,.5,.975))
quantile.values1p0 <- apply(X = x.betat1p0, MARGIN = 1, FUN = quantile, probs = c(.025,.5,.975))
quantile.values1p1 <- apply(X = x.betat1p1, MARGIN = 1, FUN = quantile, probs = c(.025,.5,.975))
quantile.values0p0 <- apply(X = x.betat0p0, MARGIN = 1, FUN = quantile, probs = c(.025,.5,.975))

par(mar=c(3,3,3,2),cex.lab=1.2,cex.axis=1.2,mgp=c(1.5,0.5,0), cex.main=1.5, cex=0.8,bg="white")
plot(x = c(60,75), y = c(0,0.7),ylab = "Density",xlab = "Implementation score (%)",
     main = "(b) Density plot of predicted implementation score (%)", type = "n") 
lines(density(x.betat0p1),lty=1,lwd=2)
lines(density(x.betat1p0),lty=6, lwd=2)
lines(density(x.betat1p1),lty=3, lwd=2)
lines(density(x.betat0p0),lty=2, lwd=2)
segments(x0=quantile.values0p1[1],y0=0.1,x1=quantile.values0p1[3],y1=0.1)
segments(x0=quantile.values1p0[1],y0=0.08,x1=quantile.values1p0[3],y1=0.08,lty=6)
segments(x0=quantile.values1p1[1],y0=0.06,x1=quantile.values1p1[3],y1=0.06,lty=3)
segments(x0=quantile.values0p0[1],y0=0.04,x1=quantile.values0p0[3],y1=0.04,lty=2)
legend("topleft", legend=c("Territory=0,PS=1", "Territory=1,PS=0","Territory=1,PS=1","Territory=0,PS=0"),lty=c(1,6,3,2), cex=1.2)
# check number
mean(x.betat1p1)-mean(x.betat1p0)
quantile.values1p1[1]-quantile.values1p0[1]
quantile.values1p1[3]-quantile.values1p0[3]
quantile.values1p1[2]-quantile.values1p0[2]

#---------------------------------------------#
# Appendix
#---------------------------------------------#
# 1.
rm(list = ls())
dt =read.csv("ged181.csv")
actorname = c("PWG","MCC","NSCN-IM","ATTF","PLA","Sikh insurgents","Kashmir insurgents","ULFA","NDFB")
newd = as.data.frame(actorname)
newd$lat = NULL; newd$lon = NULL
for (i in 1:length(actorname)) {
  newd$lat[i] = median(dt$latitude[dt$side_b==actorname[i]])
  newd$lon[i] = median(dt$longitude[dt$side_b==actorname[i]])
}
newd$actorname <- as.character(newd$actorname)
library(rworldmap)
newmap <- getMap(resolution = "low")
plot(newmap, xlim = c(85, 86), ylim = c(12, 40), asp = 1)
text(newd$lon,newd$lat,col="red",cex=1)
points(90.268665592, 26.3999984, col = "blue",cex=2,pch=19)
text(90.268665592, 28.3999984, c("Bodoland"),col = "blue")
for (i in 1:9) {
  text(95,41-(i+0.5),c(i),cex=0.9)
  text(103,41-(i+0.5),c(newd$actorname[i]),cex=0.7)
}
# 2. 
rm(list = ls())
dt = read.csv("data.csv")
sub = unique(dt[dt$year_count==1, c("country","sg_power_vdem_m1")])
sub = sub[order(sub$sg_power_vdem_m1), ]
sub$sg_power_vdem_m1 = round(sub$sg_power_vdem_m1, 3)
library(htmlTable)
htmlTable(sub, rnames=1:nrow(sub))

# 4.
rm(list = ls())
dt = read.csv("data.csv")
dt$total_y <- dt$milobs_y+dt$police_y+dt$troop_y
dt$total_y[dt$country=="India"] = 0 # make the UN missions in India as 0 --> because the are deployed was irrelevant
# power-sharing provision
dt$pow_prov = ifelse(dt$powtran_prov==1|dt$terpow_prov==1,1,0)
# subset dataset
dt$log_gdp = log(dt$gdp_m1)
dt$log_pop = log(dt$pop_m1)
sub = na.omit(dt[,c("score_nonUN","total_y","political_mission","bd_best","log_gdp","log_pop","elec_index_m1",
                    "sg_power_vdem_m1","conf_durat_year_m1","numberofreb_m1","pow_prov","terrcont","leverage_m1")])
library(stargazer)
stargazer(sub,type="text")

# 5. Table (Random effects model) ---------------#
dt = read.csv("data.csv")
head(dt)
# total number of troops variable
dt$total_y <- dt$milobs_y+dt$police_y+dt$troop_y
dt$total_y[dt$country=="India"] = 0 # make the UN missions in India as 0 --> because the are deployed was irrelevant
# power-sharing provision
dt$pow_prov = ifelse(dt$powtran_prov==1|dt$terpow_prov==1,1,0)
# subset dataset
sub = na.omit(dt[,c("score_nonUN","score_nonUN_lag","total_y","political_mission","bd_best","gdp_m1","pop_m1","elec_index_m1","country","year",
                    "sg_power_vdem_m1","conf_durat_year_m1","numberofreb_m1","pam_caseid","pow_prov","terrcont","leverage_m1")])

library(plm)
# only total personnel
form1 <- score_nonUN ~ score_nonUN_lag + log(total_y+1) + log(bd_best+1) + log(gdp_m1) + log(pop_m1) + elec_index_m1 + sg_power_vdem_m1 + 
  log(conf_durat_year_m1+1) + numberofreb_m1 + leverage_m1 + terrcont*pow_prov 
# only political mission
form2 <- score_nonUN ~ score_nonUN_lag + political_mission + log(bd_best+1) + log(gdp_m1) + log(pop_m1) + elec_index_m1 + sg_power_vdem_m1 + 
  log(conf_durat_year_m1+1) + numberofreb_m1 + leverage_m1 + terrcont*pow_prov 
# both
form3 <- score_nonUN ~ score_nonUN_lag + log(total_y+1) + political_mission + log(bd_best+1) + log(gdp_m1) + log(pop_m1) + elec_index_m1 + sg_power_vdem_m1 + 
  log(conf_durat_year_m1+1) + numberofreb_m1 + leverage_m1 + terrcont*pow_prov 

mod.re.1 = plm(form1, index = c("pam_caseid","year"),data=sub,model="random")
mod.re.2 = plm(form2, index = c("pam_caseid","year"),data=sub,model="random")
mod.re.3 = plm(form3, index = c("pam_caseid","year"),data=sub,model="random")
summary(mod.re.1, robust=T)
summary(mod.re.2, robust=T)
summary(mod.re.3, robust=T)

# 6. Table (System GMM) ------------------------#
# system GMM
form2 <- score_nonUN ~ lag(score_nonUN, 1) + log(total_y+1) + log(bd_best+1) + 
  log(gdp_m1) + log(pop_m1) + elec_index_m1 + sg_power_vdem_m1 + leverage_m1 + 
  log(conf_durat_year_m1+1) + numberofreb_m1 + terrcont + leverage_m1 + terrcont*pow_prov| lag(score_nonUN, 2:99)
mod2 <- pgmm(form2,data=sub, index = c("pam_caseid","year"),
             effect="individual",model="onestep",transformation = "ld")
summary(mod2, robust=T)

form3 <- score_nonUN ~ lag(score_nonUN, 1) + political_mission + log(bd_best+1) + 
  log(gdp_m1) + log(pop_m1) + elec_index_m1 + sg_power_vdem_m1 + leverage_m1 + 
  log(conf_durat_year_m1+1) + numberofreb_m1 + terrcont + leverage_m1 + terrcont*pow_prov| lag(score_nonUN, 2:99)
mod3 <- pgmm(form3,data=sub, index = c("pam_caseid","year"),
             effect="individual",model="onestep",transformation = "ld")
summary(mod3, robust=T)

form4 <- score_nonUN ~ lag(score_nonUN, 1) + log(total_y+1) + log(bd_best+1) + political_mission +
  log(gdp_m1) + log(pop_m1) + elec_index_m1 + sg_power_vdem_m1 + leverage_m1 + 
  log(conf_durat_year_m1+1) + numberofreb_m1 + terrcont + leverage_m1 + terrcont*pow_prov| lag(score_nonUN, 2:99)
mod4 <- pgmm(form4,data=sub, index = c("pam_caseid","year"),
             effect="individual",model="onestep",transformation = "ld")
summary(mod4, robust=T)

